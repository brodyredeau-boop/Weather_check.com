NWS Weather Live — test build

HOW TO TRY IT
1. Open index.html in a modern browser. Some browsers block GPS and network requests for local files.
2. For best results, run it from a local web server or upload the folder to a free static host's preview/staging environment.
3. Tap “Use my GPS location” and allow location access, or use the built-in Helena, Montana demo location.
4. The page fetches current observations, forecast, and active alerts from api.weather.gov and refreshes every 5 minutes while open.

IMPORTANT LIMITATIONS
- This is a working starter, not an official NWS product.
- The radar panel opens the official NWS radar website; its six-hour animation controls are on that official map. This starter does not yet build its own radar timeline or overlay risk layers.
- The NWS API does not provide a universal probability for every hazard. Official alerts/outlooks are shown rather than invented probabilities.
- GPS generally requires HTTPS or localhost. Opening index.html directly may block GPS or some API requests.
- Weather APIs and image services can have outages or rate limits. No web page can guarantee continuous updates if the device/browser is offline.
